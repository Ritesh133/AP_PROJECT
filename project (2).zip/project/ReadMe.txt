PROJECT PARTICIPANTS:
Harsh Upadhyay, roll no- 2022203
Ritesh Kumar Parihar, roll no- 2022407

GitHub Repository link:
https://github.com/Harsh9214123/AP_PROJECT


# Stick Hero Game

Stick Hero Game is a simple JavaFX game where the player controls a character who has to cross platforms by extending a stick.

## Getting Started

These instructions will help you run the game on your local machine.


HOW TO RUN:

Open the project in your preferred Java IDE.
Run the StickHeroGame class to start the game.



HOW TO PLAY:

Press the Play button to start the game.
Use the SPACE key to extend the stick. Release the key to stop extending.
Try to cross platforms by extending the stick to the next platform.
Collect cherries to increase your score.
If the stick is too short or too long, your character will fall, and the game will end.



FEATURES:

Dynamic platform generation.
Score tracking system.
Cherry collection system.
Simple and intuitive controls.



BUILT WITH:
Java
JavaFX

